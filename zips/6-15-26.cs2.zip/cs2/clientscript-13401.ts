//
function script13401(int0: number): number {
    var int1 = 0;
    var int2 = 0;
    [int1, int2] = script11929(int0);
    return int1;
}