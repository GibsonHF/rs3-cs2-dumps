//
function script18802(): number {
    var int0 = ((((varbitplayer_55953 + varbitplayer_55956) + varbitplayer_55955) + varbitplayer_55952) + varbitplayer_55954);
    if ((int0 >= 2)) {
        return 1;
    };
    return 0;
}