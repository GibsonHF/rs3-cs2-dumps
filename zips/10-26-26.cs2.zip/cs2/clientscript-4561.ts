//
function script4561(int0: number, int1: number, string0: string): void {
    var int2 = comp(589, 9);  // lobbyscreen_pane_friendschat:friendschat_active_bg
    if ((CC_FIND(int0, int1) == 1)) {
        IF_SETHIDE(false, int2);
        IF_SETPOSITION(IF_GETX(int2), CC_GETY(), 0, 0, int2);
    };
    return;
}