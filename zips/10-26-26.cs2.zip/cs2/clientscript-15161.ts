//
function script15161(): void {
    script15151(1, 1);
    script8841(92, 0);
    IF_SETHIDE(true, comp(653, 13));  // event_crafting:amount_selection
    IF_SETHIDE(true, comp(1477, 807));  // toplevel_v2:event_crafting_background
    return;
}