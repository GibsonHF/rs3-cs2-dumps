//
function script341(int0: number, int1: number): void {
    var int2 = false;
    if ((int1 == 1)) {
        int2 = true;
    };
    if ((IF_GETHIDE(int0) == true)) {
        if ((int2 == false)) {
            IF_SETHIDE(int2, int0);
            script9579(int0);
            script9581(IF_GETPARENTLAYER(IF_GETPARENTLAYER(IF_GETPARENTLAYER(int0))));
        } else if (((IF_GETHIDE(int0) == false) && (int2 == true))) {
            IF_SETHIDE(int2, int0);
            script9579(int0);
            script9581(IF_GETPARENTLAYER(IF_GETPARENTLAYER(IF_GETPARENTLAYER(int0))));
        };
    } else if (((IF_GETHIDE(int0) == false) && (int2 == true))) {
        IF_SETHIDE(int2, int0);
        script9579(int0);
        script9581(IF_GETPARENTLAYER(IF_GETPARENTLAYER(IF_GETPARENTLAYER(int0))));
    };
    return;
}