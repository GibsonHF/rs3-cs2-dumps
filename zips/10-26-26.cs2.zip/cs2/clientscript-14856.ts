//
function script14856(int0: number): void {
    SOUND_VORBIS_VOLUME(48233 as vorbis, 1, 0, 200);
    varclient_6761 = int0;
    script14857(int0);
    IF_SETHIDE(true, comp(691, 96));  // arch_relic_management:relic_info_selected_members_layer
    var int1 = 0;
    var int2 = enum_getvalue(0, 74, 14090 as cs2enum, int0);
    if ((int2 != -1 as dbrow)) {
        int1 = script14606(varplayer_12086, dbrow_getfield(int2, 385024, 0));
        if (((MAP_MEMBERS() == 0) && (dbrow_getfield(int2, 385072, 0) == 1))) {
            IF_SETHIDE(false, comp(691, 96));  // arch_relic_management:relic_info_selected_members_layer
        };
    };
    switch (int1) {
        case 0: {
            script13971(45285447, 45285448, 28553, "Unavailable", 1);
            break;
        }
        case 1: {
            script13969(45285447, 45285448, 28553, "Harness Power");
            break;
        }
        case 2: {
            script13969(45285447, 45285448, 28554, "Unharness Power");
            break;
        }
    };
    script14844(45285427, -1, -1, 45285466, 45285467, enum_getvalue(0, 74, 14090 as cs2enum, int0));
    IF_SETTEXT(TOSTRING_LOCALISED(script14612(int2), 1), comp(691, 102));  // arch_relic_management:relic_info_monolith_text
    IF_SETTEXT(TOSTRING_LOCALISED(script14611(int2), 1), comp(691, 104));  // arch_relic_management:relic_info_currency_text
    return;
}