//
function script3762(int0: number, int1: number): number {
    var int2 = 0;
    if ((CC_FIND(int0, int1) == 1)) {
        int2 = script3764();
    } else if (((int1 == -1) && (IF_FIND(int0) == 1))) {
        int2 = script3764();
    };
    return int2;
}