//
function script18578(int0: number, int1: number): string {
    if ((int1 > 0)) {
        return `Reduces the target's ${script18576(1, 1, 1)} by <col=ffffff>${inttostring(int0, 10)}%</col> for <col=ffffff>${script15973(int1, 1)}</col>`;
    };
    return `Reduces the target's ${script18576(1, 1, 1)} by <col=ffffff>${inttostring(int0, 10)}%</col>`;
}