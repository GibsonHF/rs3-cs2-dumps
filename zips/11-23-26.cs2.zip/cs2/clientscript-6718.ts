//
function script6718(): void {
    var int0 = comp(744, 139);  // loginscreen:continue_text
    IF_SETONTIMER(callback(), comp(744, 349));  // loginscreen:options_firstrun
    IF_SETONCLICK(callback(script2944), int0);
    IF_SETONTIMER(callback(), int0);
    LOGIN_RESETREPLY();
    script2954(1);
    return;
}