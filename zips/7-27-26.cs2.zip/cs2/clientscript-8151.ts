//
function script8151(int0: number, int1: number, int2: number, int3: number): void {
    script15979(int0, int1, int2, int3);
    return;
}