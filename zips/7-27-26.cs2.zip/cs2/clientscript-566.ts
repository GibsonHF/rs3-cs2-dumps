//
function script566(int0: number, int1: number, int2: number, int3: number, int4: number, int5: number, int6: number): void {
    script3412(int0, int1, int2, int3, int4, int5, int6);
    return;
}