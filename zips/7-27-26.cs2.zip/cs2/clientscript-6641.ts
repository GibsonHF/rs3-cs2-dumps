//
function script6641(): number {
    switch (script6061(2)) {
        case 0: {
            return 5000;
        }
        case 1: {
            return 25000;
        }
        case 2: {
            return 80000;
        }
        case 3: {
            return 150000;
        }
    };
    return 5000;
}