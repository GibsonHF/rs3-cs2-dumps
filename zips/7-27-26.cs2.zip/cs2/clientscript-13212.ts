//
function script13212(int0: number, int1: number): void {
    switch (int0) {
        case 1: {
            varclient_5934 = SETBIT(varclient_5934, int1);
            break;
        }
        case 2: {
            varclient_5935 = SETBIT(varclient_5935, int1);
            break;
        }
    };
    return;
}