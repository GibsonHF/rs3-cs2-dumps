//
function script8348(int0: number, int1: number): void {
    var int2 = 3;
    if (((int1 == 1) || (int1 == 3))) {
        int2 = 11;
    };
    script8349(int0, int2, int1);
    return;
}