//
function script20837(int0: number): string {
    switch (int0) {
        case 0: {
            return varclient_8452;
        }
        case 1: {
            return varclient_8453;
        }
        case 2: {
            return varclient_8454;
        }
        case 3: {
            return varclient_8455;
        }
        case 4: {
            return varclient_8456;
        }
        case 5: {
            return varclient_8457;
        }
        case 6: {
            return varclient_8458;
        }
        case 7: {
            return varclient_8459;
        }
        case 8: {
            return varclient_8460;
        }
        case 9: {
            return varclient_8461;
        }
        case 10: {
            return varclient_8462;
        }
        case 11: {
            return varclient_8463;
        }
        case 12: {
            return varclient_8464;
        }
        case 13: {
            return varclient_8465;
        }
        case 14: {
            return varclient_8466;
        }
        case 15: {
            return varclient_8467;
        }
        case 16: {
            return varclient_8468;
        }
        case 17: {
            return varclient_8469;
        }
        case 18: {
            return varclient_8470;
        }
        case 19: {
            return varclient_8471;
        }
    };
    return "";
}