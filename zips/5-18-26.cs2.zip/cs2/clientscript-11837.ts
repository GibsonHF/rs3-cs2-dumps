//
function script11837(int0: int, int1: int): int {
    if ((int1 < 1)) {
        return int0;
    };
    return script12422(int0, int1, 60);
}