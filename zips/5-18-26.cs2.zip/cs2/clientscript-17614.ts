//
function script17614(int0: component, int1: int, int2: int, int3: int, int4: int, int5: int, int6: int, int7: int, int8: int, int9: int, int10: int, int11: unknown_int, int12: unknown_int, int13: dbrow, int14: unknown_int, int15: unknown_int): void {
    script17613(int0, int1, int2, int3, int4, int5, int6, int7, int8, int9, int10, int11, int12, int13, int14);
    script17616(int14, int15);
    return;
}