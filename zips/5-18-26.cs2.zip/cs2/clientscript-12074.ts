//
function script12074(int0: int): int {
    switch (int0) {
        case 1: {
            return 0;
        }
        case 2: {
            return 1160;
        }
        case 3: {
            return 2607;
        }
        case 4: {
            return 5176;
        }
        case 5: {
            return 8285;
        }
        case 6: {
            return 11760;
        }
        case 7: {
            return 15835;
        }
        case 8: {
            return 21152;
        }
        case 9: {
            return 28761;
        }
        case 10: {
            return 40120;
        }
        case 11: {
            return 57095;
        }
        case 12: {
            return 81960;
        }
        case 13: {
            return 117397;
        }
        case 14: {
            return 166496;
        }
        case 15: {
            return 232755;
        }
        case 16: {
            return 320080;
        }
        case 17: {
            return 432785;
        }
        case 18: {
            return 575592;
        }
        case 19: {
            return 753631;
        }
        case 20: {
            return 972440;
        }
    };
    return 0;
}